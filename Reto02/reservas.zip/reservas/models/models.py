# -*- coding: utf-8 -*-
from odoo import models, fields, api

#Modelo de Reservas
class reservas_reservas(models.Model):

    #Nombre del modelo
    _name = 'reservas.reservas_reservas'
    #Descripcion de modelo
    _description = 'reservas.reservas_reservas'

    #Fecha a la que se hace la reserva
    fecha = fields.Date(string='Fecha de la Reserva', required=True)
    #Turno en el que se realiza la reserva
    turno = fields.Many2one('reservas.reservas_turno')
    #Numero de personas de la reserva
    numero_personas = fields.Integer(string='Número de Personas', required=True)
    #Mesa en la que se reserva
    mesa_id = fields.Many2one('restaurante.mesa', string='Mesa', required=True)
    #Clientes que hace la reserva
    cliente_id = fields.Many2one('res.partner', string='Cliente', required=True)
    #Empleado que atiende la reserva
    empleado_id = fields.Many2one('hr.employee', string='Empleado', required=True)
    #Productos que se venderán en la reserva
    producto_id = fields.Many2one('product.template', string='Producto', required=True)
    #Estado de la reserva
    estado = fields.Selection([
        ('confirmada', 'Confirmada'),
        ('cancelada', 'Cancelada'),
        ('en_espera', 'En espera'),
        ('completada', 'Completada'),
    ], string='Estado', default='en_espera', required=True)
    
    @api.onchange('numero_personas')
    def asignar_mesas(self):
        for reserva in self:
            if reserva.numero_personas > 4:
                # Calcular el número de mesas adicionales requeridas
                num_mesas_adicionales = (reserva.numero_personas - 4) // reserva.mesa_id.capacidad + 1
                # Crear las mesas adicionales
                mesas_adicionales = self.env['restaurante.mesa'].search([('cliente_id', '=', False)], limit=num_mesas_adicionales)
                # Asignar las mesas adicionales a la reserva
                reserva.mesa_id |= mesas_adicionales


#Modelo de Turno
class reservas_turno(models.Model):
    
    #Nombre del modelo
    _name = 'reservas.reservas_turno'
    #Descripcion de modelo
    _description = 'Turnos de reserva para el restaurante'

    #Hora del turno
    hora = fields.Float(string='Turno', required=True)
    #Campo para enlazar con el model reservas.reservas_reservas
    reserva_id = fields.Many2one('reservas.reservas_reservas', string='Reserva', inverse_name='turno')


#Modelo mesa
class Mesa(models.Model):
    
    #Nombre del modelo
    _name = 'restaurante.mesa'
    #Descripcion de modelo
    _description = 'Mesas del restaurante'

    #Numero de la mesa dentro de restaurante
    numero = fields.Char(string='Número de mesa', required=True)
    #Capacidad de personas que caben en la mesa
    capacidad = fields.Integer(string='Capacidad de la mesa', required=True)
    #Cliente que tiene reservada la mesa
    cliente_id = fields.Many2one('res.partner', string='Cliente')
